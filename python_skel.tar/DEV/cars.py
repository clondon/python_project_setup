from os import sys
import math

# if sys:
#    print("Command line", sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])


class Circle:
    def __init__(self, radius):
       self.radius = radius

    def circle(Self):
        return radius
    
    def area(self):
        return math.pi * self.radius * 2
    
    def circumference(self):
        return math.pi * self.radius * self.radius
       

p1 = Circle(7)
print("Value for p1.radius", p1)
print("Value for p1.area", p1.area())
print("Value for p1.Circumference", p1.circumference())

