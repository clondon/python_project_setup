from os import sys
import math


# if sys:
#    print("Command line", sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])


class Circle:
    print("Calling the cirlce class")
    def __init__(self, radius):
        self.radius = radius
 
        
    def area(self):
        area1 = area * 2
        return area1
        


circle= Circle(4)

area = circle.area
print(area.content)